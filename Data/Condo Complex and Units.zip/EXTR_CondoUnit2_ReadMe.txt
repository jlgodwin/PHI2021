New condo units extract file has 8 more columns than the old one.  These are the additional columns:
	Situs Address		Character 83
	Building Number		Character 5
	Fraction		Character 3
	Direction Prefix	Character 2
	Street Name		Character 25
	Street Type		Character 4
	Direction Suffix	Character 2
	UnitDescr		Character 25
	Zip code		Character 10


Please plan on using the new extract (Extr_CondoUnit2).  Future download will exclude the old one (Extr_CondoUnit).